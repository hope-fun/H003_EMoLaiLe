/** Created with JetBrains WebStorm.
 * User: yjtx
 * Date: 14-10-20
 * Time: 上午9:36
 * Class: DOMUIAssetPrototype.d.ts
 * Summary:
 */
declare module egret.dom {
    function resetUIAsset():void;
}