## ParticleSystem使用手册

------------------


### 概述
该粒子库是基于 Egret 引擎做的扩展，目前提供了重力系统粒子库 GravityParticleSystem。在canvas模式下，建议粒子数量不要超过200个。

访问 [这里](http://docs.egret-labs.org/post/manual/particle/aboutparticle.html) 查看详细的文档
