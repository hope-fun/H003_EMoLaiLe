class GestureState {
    public static POSSIBLE:string = "possible";

    public static RECOGNIZED:string = "recognized";

    public static FAILED:string = "failed";

    public static BEGAN:string = "began";

    public static CHANGED:string = "changed";

    public static ENDED:string = "ended";

    public static CANCELLED:string = "cancelled";
}
