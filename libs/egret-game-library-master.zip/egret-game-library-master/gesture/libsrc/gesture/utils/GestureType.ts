class GestureType {
    public static DOUBLE_TAP:string = "doubleTap";
    public static PINCH:string = "pinch";
}
