var DCAgentInitConfig = function() {};
var DCAgentPaymentConfig = function() {};
